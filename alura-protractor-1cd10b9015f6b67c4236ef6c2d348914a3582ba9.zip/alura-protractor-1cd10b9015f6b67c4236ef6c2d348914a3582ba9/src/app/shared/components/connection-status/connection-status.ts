export interface ConnectionStatus {
    online: boolean
}