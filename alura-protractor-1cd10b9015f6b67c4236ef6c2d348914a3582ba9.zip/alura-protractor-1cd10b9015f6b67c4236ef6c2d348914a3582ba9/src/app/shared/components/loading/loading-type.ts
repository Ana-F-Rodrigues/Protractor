export enum LoadingType {
    LOADING = 'loading',
    STOPPED = 'stopped'
}