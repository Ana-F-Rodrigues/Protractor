export interface ServerLog {
    message: string;
    acessedUrl: string;
    userName: string;
    stackAsString: string;
}