export const environment = {
  production: true,
  ApiUrl: 'http://localhost:3000',
  serverLog: 'http://localhost:7000'
};
